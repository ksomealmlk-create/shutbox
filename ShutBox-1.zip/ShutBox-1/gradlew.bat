@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo ERROR: Gradle executable not found. AIDE must provide Gradle 8.2.2.
exit /b 127
